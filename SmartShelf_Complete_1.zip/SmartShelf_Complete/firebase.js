// firebase.js
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import { getAuth } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";
import { getFirestore } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "AIzaSyCWSxv1uzSP0C70Etbm4RzaWGk63F76eM8",
  authDomain: "smart-shelf-fa803.firebaseapp.com",
  projectId: "smart-shelf-fa803",
  storageBucket: "smart-shelf-fa803.firebasestorage.app",
  messagingSenderId: "1056207406246",
  appId: "1:1056207406246:web:618d27ec6135a4643e2067",
  measurementId: "G-16G946KBJG"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Export Auth and Firestore
export const auth = getAuth(app);
export const db = getFirestore(app);  